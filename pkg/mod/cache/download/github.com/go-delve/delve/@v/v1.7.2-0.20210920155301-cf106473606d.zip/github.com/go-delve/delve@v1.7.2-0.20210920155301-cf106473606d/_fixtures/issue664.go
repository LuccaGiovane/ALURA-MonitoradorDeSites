package main

func asdfasdf() {
	for i := 0; i < 5; i++ {
		for i := 0; i < 5; i++ {
			//...
		}
		//...
	}
}

func main() {
	asdfasdf()
}
